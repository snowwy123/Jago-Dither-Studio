Jago Wobble Studio PNG sequence

Import frame-0001.png as an image sequence at 12 frames per second.
Numbered PNGs contain the full rendered motion, including layer and selection effects.
Frames: 24; size: 480 x 320; playback: 2.000000 seconds.
The source loop is 2.000000 seconds; output rounds up to a whole frame.
The repeated loop endpoint is omitted. timing.json lists every frame.
